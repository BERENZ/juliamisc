# UEP-Workshop-20190405
Materials for Julia workshop in UEP on 2019-04-05

See the `installation.jl` file for environment setup instructions.
